package com.minkov.springintroapp.restModels;

public class CarRequestModel {
    String model;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
