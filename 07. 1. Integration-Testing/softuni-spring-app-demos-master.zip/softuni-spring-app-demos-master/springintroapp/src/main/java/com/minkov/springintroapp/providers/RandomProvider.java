package com.minkov.springintroapp.providers;

public interface RandomProvider {
    int getRandomInt();
}
