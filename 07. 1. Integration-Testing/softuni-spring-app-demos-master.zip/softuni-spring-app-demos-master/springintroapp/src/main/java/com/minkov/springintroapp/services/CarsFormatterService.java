package com.minkov.springintroapp.services;

public interface CarsFormatterService {
    String getCarCreatedEmailBody(String model);
}
