package org.softuni.productshop.domain.models.rest;

public class ProductOrderRequestModel {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
