package org.softuni.productshop;

public class GlobalConstants {
    public static final String VIEW_MODEL_OBJECT_NAME = "VIEW-MODEL";
}
