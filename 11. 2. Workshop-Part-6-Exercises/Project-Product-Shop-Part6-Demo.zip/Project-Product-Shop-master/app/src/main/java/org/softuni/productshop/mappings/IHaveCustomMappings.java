package org.softuni.productshop.mappings;

import org.modelmapper.ModelMapper;

public interface IHaveCustomMappings {
    void configureMappings(ModelMapper mapper);
}
