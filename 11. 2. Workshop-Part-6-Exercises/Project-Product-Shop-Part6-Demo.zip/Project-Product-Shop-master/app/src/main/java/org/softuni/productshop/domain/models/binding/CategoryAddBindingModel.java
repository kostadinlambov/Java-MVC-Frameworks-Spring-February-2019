package org.softuni.productshop.domain.models.binding;

public class CategoryAddBindingModel {

    private String name;

    public CategoryAddBindingModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
